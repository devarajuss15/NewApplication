package com.example.mahadev.newapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.mahadev.newapplication.TableData.TableInfo;
/**
 * Created by mahadev on 1/28/2017.
 */
public class DatabaseOperations extends SQLiteOpenHelper {
    public static final int database_version=1;
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " +TableInfo.TABLE_NAME + " (" +
                    TableInfo.EMAIL_ID + " INTEGER PRIMARY KEY," +
                    TableInfo.PASSWORD + " TEXT," +
                    TableInfo.USER_NAME + " TEXT,"+
                    TableInfo.MOBILE_NO + " NUMBER);";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TableInfo.TABLE_NAME;
    //public String CREATE_QUERY="CREATE TABLE "+TableInfo.TABLE_NAME+" ("+TableInfo.EMAIL_ID+" TEXT,"+TableInfo.PASSWORD+" TEXT,"+TableInfo.USER_NAME+" TEXT,"+TableInfo.MOBILE_NO+" NUMBER);";

    public DatabaseOperations(Context context){
        super(context, TableInfo.DATABASE_NAME,null,database_version);
        Log.d("Database operations", "Database created");
    }

    @Override
    public void onCreate(SQLiteDatabase sdb) {
        sdb.execSQL(SQL_CREATE_ENTRIES);
        Log.d("Database operations", "Table created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sdb, int i, int i1) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        sdb.execSQL(SQL_DELETE_ENTRIES);
        onCreate(sdb);

    }
    public void onDowngrade(SQLiteDatabase sdb, int oldVersion, int newVersion) {
        onUpgrade(sdb, oldVersion, newVersion);
    }
    public void putInformation(DatabaseOperations dop,String id,String pass,String name,String mobileno){
        SQLiteDatabase SQ=dop.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(TableInfo.EMAIL_ID,id);
        cv.put(TableInfo.PASSWORD,pass);
        cv.put(TableInfo.USER_NAME,name);
        cv.put(TableInfo.MOBILE_NO,mobileno);
        long k=SQ.insert(TableInfo.TABLE_NAME, null, cv);
        Log.d("Database operations", "one row inserted");



    }
    public Cursor getInformation(DatabaseOperations dop){
        SQLiteDatabase SQ=dop.getReadableDatabase();
        String[] columns={TableInfo.EMAIL_ID,TableInfo.PASSWORD,TableInfo.USER_NAME,TableInfo.MOBILE_NO};
        Cursor CR=SQ.query(TableInfo.TABLE_NAME,columns,null,null,null,null,null);
        return CR;

    }
}
