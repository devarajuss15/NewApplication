package com.example.mahadev.newapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;

public class thirdactivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private EditText EventName;
    private EditText Location;
    private TextView Date;
    private Button CreateEvent;
    private DatePicker dobPicker;
    private RadioButton Remindme;
    private static final String TAG = "thirdactivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdactivity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        firebaseAuth = FirebaseAuth.getInstance();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        databaseReference = FirebaseDatabase.getInstance().getReference();
        EventName = (EditText) findViewById(R.id.editText7);
        Location = (EditText) findViewById(R.id.editText9);
        dobPicker = (DatePicker) findViewById(R.id.datePicker);


        Button button = (Button) findViewById(R.id.button4);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEventInfo();
                //retrieveEventInfo();
                startActivity(new Intent(getApplicationContext(), GetContactsActivity.class));
            }

        });
    }

    private void saveEventInfo() {
        //String selectedDate = DateFormat.getDateInstance().format(DatePicker.getCalendarView().getDate());
        int dobYear = dobPicker.getYear();
        int dobMonth = dobPicker.getMonth();
        int dobDate = dobPicker.getDayOfMonth();
        Calendar calendar = Calendar.getInstance();
        calendar.set(dobYear, dobMonth, dobDate);
        SimpleDateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
        //Date d = new Date(dobYear, dobMonth, dobDate);
        String strDate = dateFormatter.format(calendar.getTime());
        //StringBuilder sb=new StringBuilder();
        //sb.append(dobYear.toString()).append("-").append(dobMonth.toString()).append("-").append(dobDate.toString());
        //String dobStr=sb.toString().trim();

        String eventName = EventName.getText().toString().trim();
        String loc = Location.getText().toString().trim();
        EventInfo eventinfo = new EventInfo(eventName, loc, strDate);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        databaseReference.child("Events").setValue(eventinfo);
        Toast.makeText(this, "event created!", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(thirdactivity.this, NavigationActivity.class);
        intent.putExtra("name", eventName);
        intent.putExtra("date", strDate);

        startActivity(intent);

    }

    /*public String[] retrieveEventInfo() {
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Events");
        String userId = databaseReference.push().getKey();
        final String[] string = new String[]{};

        //Get datasnapshot at your "users" root node
        DatabaseReference ref = databaseReference;
        //Firebase ref = new Firebase("https://docs-examples.firebaseio.com/web/saving-data/fireblog/posts");
        //Map<String, String> chatInfo = new HashMap<String, String>();
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Log.d(TAG, "There are " + snapshot.getChildrenCount() + " blog posts");
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    EventInfo post = postSnapshot.getValue(EventInfo.class);
                    Log.d(TAG, post.getDatePick());
                    string[0] = post.getDatePick();
                    string[1]=post.getEventName();

                }
                //Get map of users in datasnapshot
                //collectLocations((Map<String, String>) dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //handle databaseError
            }
        });
        return (string);

    }*/
}

