package com.example.mahadev.newapplication;

import java.util.ArrayList;

/**
 * Created by mahadev on 2/11/2017.
 */
public class EventInfo {
    public String EventName;
    public String Location;
    public String DatePick;
    //public ArrayList<String> groupmem;
    public EventInfo(){

    }

    public EventInfo(String eventName,String location, String date) {
        EventName = eventName;
        Location = location;
        DatePick=date;
        //groupmem=Groupmem;
    }

    /*public String getEventName() {
        return EventName;
    }

    public void setEventName(String eventName) {
        EventName = eventName;
    }*/

    /*public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    /*public String getDatePick() {

        return DatePick;
    }

    /*public void setDatePick(String datePick) {
        DatePick = datePick;
    }*/
}
