package com.example.mahadev.newapplication;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import  android.text.format.DateFormat;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ChatActivity extends AppCompatActivity implements LocationListener{
    private static final String TAG = "ChatActivity";
    private static final long INTERVAL = 1000 * 60 * 1; //1 minute
    private static final long FASTEST_INTERVAL = 1000 * 60 * 1; // 1 minute
    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;
    Location mCurrentLocation;
    String mLastUpdateTime;
    GoogleMap googleMap;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;



    private static int SIGN_IN_REQUEST_CODE = 1;
    private FirebaseListAdapter<ChatMessage> adapter;
    RelativeLayout activity_chat;


    LocationManager locationManager;
    String mprovider;
    /*LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    double longitude = location.getLongitude();
    double latitude = location.getLatitude();*/

    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_sign_out) {
            AuthUI.getInstance().signOut(this).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Snackbar.make(activity_chat, "You have been signed out.", Snackbar.LENGTH_SHORT).show();
                    finish();
                }
            });
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SIGN_IN_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Snackbar.make(activity_chat, "suceessfully signed in -Welcome!", Snackbar.LENGTH_SHORT).show();
                displayChatMessage();

            } else {
                Snackbar.make(activity_chat, "we could not sign you in", Snackbar.LENGTH_SHORT).show();
                finish();
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        firebaseAuth=FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("chatInfo");
        String userId = databaseReference.push().getKey();

       //Get datasnapshot at your "users" root node
        DatabaseReference ref = databaseReference;
        //Firebase ref = new Firebase("https://docs-examples.firebaseio.com/web/saving-data/fireblog/posts");
        //Map<String, String> chatInfo = new HashMap<String, String>();









        /*ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //long numChildren = dataSnapshot.getChildrenCount();
                //System.out.println(count.get() + " == " + numChildren);
                ChatMessage post = dataSnapshot.getValue(ChatMessage.class);
              //  Log.d(TAG, post.getMessageText());


                String user = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                String user2=post.getMessageUser();
                if(!user.equals(user2)) {
                    String string = post.getMessageText();
                    String[] parts = string.split("-");
                    Toast.makeText(ChatActivity.this, user + "" + user2, Toast.LENGTH_LONG).show();

                    String part1 = parts[0];
                    String part2 = parts[1];
                    Log.d(TAG, part1);
                    Log.d(TAG, part2);
                    double lat = Double.parseDouble(part1);
                    double lon = Double.parseDouble(part2);
                    LatLng latLng = new LatLng(lat, lon);
                    startActivity(new Intent(ChatActivity.this, MapsActivity.class));
                    Toast.makeText(ChatActivity.this, latLng.toString(), Toast.LENGTH_LONG).show();
                    MapsActivity.draw(latLng);
                }  }

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });*/












        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String prevChildKey) {
                ChatMessage post = dataSnapshot.getValue(ChatMessage.class);
                Log.d(TAG,post.getMessageText());

                String string = post.getMessageText();
                String user = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                String user2=post.getMessageUser();
                if(!user.equals(user2))
                {
                    String[] parts =new String[3];
                    parts=string.split("-,");
                 //   try{for(int i=0;i<3;i++)
                 //   {
                  //      Toast.makeText(ChatActivity.this, parts[i], Toast.LENGTH_SHORT).show();
                  //  }}
                   // catch(ArrayIndexOutOfBoundsException e)
                    //{
                     //   Toast.makeText(ChatActivity.this,"helo"+string,Toast.LENGTH_SHORT).show();
                   // }
                    //Toast.makeText(ChatActivity.this, user+""+user2, Toast.LENGTH_LONG).show();
                   String part1 = parts[1];
                    String part2 = parts[0];
             //       String part1="71.45";
             //       String part2="17.46";
                //Log.d(TAG,part1);
                //Log.d(TAG,part2);
                //double lat = Double.parseDouble(part1);
                //double lon = Double.parseDouble(part2);
                //LatLng latLng = new LatLng(lat,lon);
                //startActivity(new Intent(ChatActivity.this, MapsActivity.class));
                Intent intent=new Intent (getBaseContext(), MapsActivity.class);
                    intent.putExtra("abcd1",part1);
                    intent.putExtra("abcd2",part2);
                    startActivity(intent);
                //Toast.makeText(ChatActivity.this, string, Toast.LENGTH_LONG).show();
             //   MapsActivity.draw(latLng);
                    //Toast.makeText(ChatActivity.this, "ekkadaki ravodhu", Toast.LENGTH_LONG).show();
                }}

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String prevChildKey) {}

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String prevChildKey) {}

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });
        /*ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Log.d(TAG,"There are " + snapshot.getChildrenCount() + " blog posts");
                for (DataSnapshot postSnapshot: snapshot.getChildren()) {
                    ChatMessage post = postSnapshot.getValue(ChatMessage.class);
                    Log.d(TAG,post.getMessageText());

                    String string = post.getMessageText();

                    String[] parts = string.split("-");
                    String part1 = parts[0];
                    String part2 = parts[1];
                    Log.d(TAG,part1);
                    Log.d(TAG,part2);
                    double lat = Double.parseDouble(part1);
                    double lon = Double.parseDouble(part2);
                    LatLng latLng = new LatLng(lat,lon);
                    startActivity(new Intent(ChatActivity.this, MapsActivity.class));
                    MapsActivity.draw(latLng);
                }
                //Get map of users in datasnapshot
                //collectLocations((Map<String, String>) dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //handle databaseError
                    }
                });*/
        /*createLocationRequest();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();

        setContentView(R.layout.activity_location_google_map);
        SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        googleMap = fm.getMap();
        googleMap.getUiSettings().setZoomControlsEnabled(true);*/

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();

        mprovider = locationManager.getBestProvider(criteria, false);

        if (mprovider != null && !mprovider.equals("")) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            Location location = locationManager.getLastKnownLocation(mprovider);
            locationManager.requestLocationUpdates(mprovider, 15000, 1, this);

            if (location != null)
                onLocationChanged(location);
            else
                Toast.makeText(getBaseContext(), "No Location Provider Found Check Your Code", Toast.LENGTH_SHORT).show();
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        activity_chat = (RelativeLayout) findViewById(R.id.activity_main);
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivityForResult(AuthUI.getInstance().createSignInIntentBuilder().build(), SIGN_IN_REQUEST_CODE);
        } else {
            Snackbar.make(activity_chat, "Welcome" + FirebaseAuth.getInstance().getCurrentUser().getEmail(), Snackbar.LENGTH_SHORT).show();
            displayChatMessage();

        }



    }

    /*private void collectLocations(Map<String,String> ChatInfo) {

        ArrayList<String> Location = new ArrayList<>();

        //iterate through each user, ignoring their UID
        for (Map.Entry<String, String> entry : ChatInfo.entrySet()){

            //Get user map
            Map<String, String> singleUser = (Map<String, String>) entry.getValue();
            //Get phone field and append to list
            Location.add((String) singleUser.get("messageText"));
        }

        System.out.println(Location.toString());
    }*/

    @Override
    public void onLocationChanged(Location location) {
        /*TextView longitude = (TextView) findViewById(R.id.textView);
        TextView latitude = (TextView) findViewById(R.id.textView1);

        longitude.setText("Current Longitude:" + location.getLongitude());
        latitude.setText("Current Latitude:" + location.getLatitude());*/

        //FirebaseUser user=firebaseAuth.getCurrentUser();
        final String longitude1=" " + location.getLongitude();
        final String latitude1=" " + location.getLatitude();
        final double lat1=location.getLatitude();
        final double lon1=location.getLongitude();
        //final String userid=" "+user.getUid();
        //FirebaseDatabase.getInstance().getReference().push().setValue(new ChatMessage(longitude1+latitude1, FirebaseAuth.getInstance().getCurrentUser().getEmail()));
        //FirebaseDatabase.getInstance().getReference().push().setValue(new ChatMessage(longitude1+latitude1, FirebaseAuth.getInstance().getCurrentUser().getEmail()));
        /*IconGenerator iconFactory = new IconGenerator(this);
        iconFactory.setStyle(IconGenerator.STYLE_PURPLE);
        options.icon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(mLastUpdateTime)));
        options.anchor(iconFactory.getAnchorU(), iconFactory.getAnchorV());

        LatLng currentLatLng = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude());
        options.position(currentLatLng);
        Marker mapMarker = googleMap.addMarker(options);
        long atTime = mCurrentLocation.getTime();
        mLastUpdateTime = DateFormat.getTimeInstance().format(new Date(atTime));
        mapMarker.setTitle(mLastUpdateTime);
        Log.d(TAG, "Marker added.............................");
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng,
                13));
        Log.d(TAG, "Zoom done.............................");*/

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText input = (EditText) findViewById(R.id.input);
                databaseReference.push().setValue(new ChatMessage(longitude1 + "-," + latitude1, FirebaseAuth.getInstance().getCurrentUser().getEmail(), "$$$$$"));
                //LatLng latLng = new LatLng(lat1, lon1);

                //startActivity(new Intent(ChatActivity.this, MapsActivity.class));
                //MapsActivity.draw(latLng);

                input.setText("");
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    private void displayChatMessage() {

        ListView listOfMessage = (ListView) findViewById(R.id.list_of_messages);
        adapter = new FirebaseListAdapter<ChatMessage>(this, ChatMessage.class, R.layout.list_item, databaseReference) {

            @Override
            protected void populateView(View v, ChatMessage model, int position) {
                TextView messageText, messageUser, messageTime;
                messageText = (TextView) v.findViewById(R.id.message_text);
                messageUser = (TextView) v.findViewById(R.id.message_user);
                messageTime = (TextView) v.findViewById(R.id.message_time);
                messageText.setText(model.getMessageText());
                messageUser.setText(model.getMessageUser());
                messageTime.setText(DateFormat.format("dd-MM-yyyy (HH:mm:ss)", model.getMessageTime()));
                //ChatMessage ch=new ChatMessage(model.getMessageText(),model.getMessageUser(),"$$$$$");
                //databaseReference.child("ChatInfo");


            }
        };
        listOfMessage.setAdapter(adapter);

    }

    private void chatInfo(){
        ChatMessage ch= new ChatMessage();
        String email =ch.getMessageUser();
        Log.d(TAG,"reached"+email);
        String loc =ch.getMessageText();
        Log.d(TAG,"reached"+loc);
        ChatUsers chatinfo=new ChatUsers(loc,email);
        FirebaseUser user=firebaseAuth.getCurrentUser();
        databaseReference.child("ChatInfo").setValue(chatinfo);
        Toast.makeText(this, "location sent!", Toast.LENGTH_LONG).show();

    }




}
