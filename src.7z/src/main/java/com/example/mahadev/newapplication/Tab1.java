package com.example.mahadev.newapplication;

/**
 * Created by mahadev on 12/14/2016.
 */
import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


public class Tab1 extends Fragment{
    private TimePicker time_picker;
    private Button button_done;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab1, container, false);


            time_picker=(TimePicker) rootView.findViewById(R.id.timePicker);
            button_done=(Button) rootView.findViewById(R.id.button3);

            button_done.setOnClickListener(
                    new View.OnClickListener(){
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(getContext(),"Watch me for"+time_picker.getCurrentHour()+ "hours"+time_picker.getCurrentMinute()+ "minutes",Toast.LENGTH_SHORT).show();
                        }
                    }
            );
        Button button=(Button)rootView.findViewById(R.id.button8);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(getContext(), MapsActivity.class));
           /* if you want to finish the first activity then just call
            finish(); */
            }
        });
        return rootView;
    }
}
