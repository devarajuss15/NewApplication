package com.example.mahadev.newapplication;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import java.util.ArrayList;
import java.util.List;

public class GetContactsActivity extends AppCompatActivity {
    // The ListView
    private ListView lstNames;
    ArrayAdapter<String> adapter;
    //private CheckedTextView ct;


    // Request code for READ_CONTACTS. It can be any number > 0.
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_contacts);

        //lstNames.setItemChecked(1,true);
        // Find the list view
        this.lstNames = (ListView) findViewById(R.id.listView);

        // Read and show the contacts
        //showContacts();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, PERMISSIONS_REQUEST_READ_CONTACTS);
            //After this point you wait for callback in onRequestPermissionsResult(int, String[], int[]) overriden method
        } else {
            // Android version is lesser than 6.0 or the permission is already granted.
            List<String> contacts = getContactNames();
            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, contacts);
            lstNames.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
            lstNames.setAdapter(adapter);
            lstNames.setItemsCanFocus(false);


        }
        //lstNames.setOnItemClickListener(new CheckBoxClick());

        lstNames.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // TODO Auto-generated method stub
                int itemposition = i;

                ArrayList<String> mylist = new ArrayList<String>();

                String value = (String) lstNames.getItemAtPosition(i);
                CheckedTextView ctv = (CheckedTextView) view;
                if (ctv.isChecked()) {
                    Toast.makeText(GetContactsActivity.this, "" + value + " checked", Toast.LENGTH_SHORT).show();
                    //mylist.add(value);
                } else {
                    Toast.makeText(GetContactsActivity.this, "" + value + " unchecked", Toast.LENGTH_SHORT).show();
                }

                SparseBooleanArray checked = lstNames.getCheckedItemPositions();
                ArrayList<String> selectedItems = new ArrayList<String>();
                for (int x = 0; x < checked.size(); x++) {
                    // Item position in adapter
                    int position = checked.keyAt(i);
                    // Add sport if it is checked i.e.) == TRUE!
                    if (checked.valueAt(i)) {
                        selectedItems.add(adapter.getItem(position));
                    }
                }
                String[] outputStrArr = new String[selectedItems.size()];

                for (int y = 0; y < selectedItems.size(); y++) {
                    outputStrArr[y] = selectedItems.get(y);
                }

                Intent intent = new Intent(getApplicationContext(),MyGroupListActivity.class);
                // Create a bundle object
                Bundle b = new Bundle();
                b.putStringArray("selectedItems", outputStrArr);

                // Add the bundle to the intent.
                intent.putExtras(b);

                // start the ResultActivity
                startActivity(intent);

                /*SparseBooleanArray checkedItemPositions = lstNames.getCheckedItemPositions();
                final int checkedItemCount = checkedItemPositions.size();
                for (int x = 0; x < checkedItemCount; x++) {
                    //int key = checkedItemPositions.keyAt(x);
                    if (checkedItemPositions.get(x)) {
                        mylist.add(value);
                    } else {
                        // item was in the sparse array, but not checked.
                    }
                }
               // Toast.makeText(GetContactsActivity.this, "" + "lollipop" + " checked", Toast.LENGTH_SHORT).show();

                /*for (i = 0; i < mylist.size(); i++) {
                    String ss=mylist.get(i);*/
                    //Toast.makeText(GetContactsActivity.this, "" +mylist  + " checked", Toast.LENGTH_SHORT).show();

            }

        });
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MyGroupListActivity.class));
            }

        });
        }

    /**
     * Show the contacts in the ListView.
     */

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_READ_CONTACTS) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission is granted
                //showContacts();
            } else {
                Toast.makeText(this, "Until you grant the permission, we canot display the names", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Read the name of all the contacts.
     *
     * @return a list of names.
     */
    private List<String> getContactNames() {
        List<String> contacts = new ArrayList<>();
        //String[] contacts = new String[]{};
        // Get the ContentResolver
        ContentResolver cr = getContentResolver();
        // Get the Cursor of all the contacts
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        // Move the cursor to first. Also check whether the cursor is empty or not.
        if (cursor.moveToFirst()) {
            // Iterate through the cursor
            do {
                // Get the contacts name
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
               // contacts[0]=name;
                contacts.add(name);
            } while (cursor.moveToNext());
        }
        // Close the curosor
        cursor.close();

        return contacts;
    }


}