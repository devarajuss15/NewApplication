package com.example.mahadev.newapplication;

/**
 * Created by mahadev on 3/1/2017.
 */
public class ChatUsers {
    public String message;
    public String email;

    public ChatUsers() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public ChatUsers(String message, String email) {
        this.message = message;
        this.email = email;
    }

}
