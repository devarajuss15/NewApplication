package com.example.mahadev.newapplication;

import android.provider.BaseColumns;

/**
 * Created by mahadev on 1/28/2017.
 */
public final class TableData {
    private TableData()
    {

    }

    public static class TableInfo implements BaseColumns {
        public static final String EMAIL_ID="email_id";
        public static final String PASSWORD="password";
        public static final String USER_NAME="user_name";
        public static final String MOBILE_NO="mobile_no";
        public static final String TABLE_NAME="user_details";
        public static final String DATABASE_NAME="myapp_db";

    }
}
